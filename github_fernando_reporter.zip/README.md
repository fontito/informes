# Dictado de Informes MSK

Página preparada para GitHub Pages: reconocimiento por voz, plantillas y texto enriquecido para informes médicos MSK.